from flask import Flask, render_template, Response, jsonify
import threading
import json
import numpy as np
import os
import csv

app = Flask(__name__)

# Paths to your log files
JSON_LOG_FILE = 'monitoring_results.json'
CSV_LOG_FILE = 'vehicle_log.csv'

# Function to simulate ESP32 stream
def gen_frames():
    import cv2
    import urllib.request
    stream = urllib.request.urlopen('http://192.168.137.134/stream')
    bytes_data = b''
    while True:
        bytes_data += stream.read(4096)
        a = bytes_data.find(b'\xff\xd8')
        b = bytes_data.find(b'\xff\xd9')
        if a != -1 and b != -1:
            jpg = bytes_data[a:b + 2]
            bytes_data = bytes_data[b + 2:]
            frame = cv2.imdecode(np.frombuffer(jpg, dtype=np.uint8), cv2.IMREAD_COLOR)
            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

# API to provide metrics from JSON
@app.route('/metrics')
def metrics():
    try:
        with open(JSON_LOG_FILE, 'r') as file:
            data = json.load(file)
        return jsonify(data)
    except FileNotFoundError:
        return jsonify({"error": "Monitoring data not available"}), 500

# API to provide log data from CSV
@app.route('/logs')
def logs():
    log_data = []
    try:
        with open(CSV_LOG_FILE, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                log_data.append(row)
    except FileNotFoundError:
        return jsonify({"error": "Log file not available"}), 500
    return jsonify(log_data)

# Route for video feed
@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Main dashboard route
@app.route('/')
def index():
    return render_template('dashboard.html')

if __name__ == '__main__':
    # Run the Flask app
    app.run(debug=True)
