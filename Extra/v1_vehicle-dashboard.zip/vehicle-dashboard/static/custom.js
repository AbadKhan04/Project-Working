// Fetch metrics periodically
function fetchMetrics() {
    fetch('/metrics')
        .then(response => response.json())
        .then(data => {
            document.getElementById('vehicle-count').textContent = `Total Vehicles: ${data.total_vehicle_count}`;
        });
}

// Fetch logs periodically
function fetchLogs() {
    fetch('/logs')
        .then(response => response.json())
        .then(data => {
            const logTable = document.getElementById('log-table');
            logTable.innerHTML = '';
            data.forEach(log => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${log.Timestamp}</td>
                    <td>${log.Vehicle_ID}</td>
                    <td>${log.Type}</td>
                    <td>${log.Speed}</td>
                    <td>${log.Overtaking}</td>
                `;
                logTable.appendChild(row);
            });
        });
}

// Update the speed chart periodically
function updateSpeedChart() {
    fetch('/logs')
        .then(response => response.json())
        .then(data => {
            const timestamps = data.map(log => log.Timestamp);
            const speeds = data.map(log => parseFloat(log.Speed));

            const trace = {
                x: timestamps,
                y: speeds,
                type: 'scatter',
                mode: 'lines+markers',
                marker: { color: 'blue' },
            };

            Plotly.newPlot('speed-chart', [trace]);
        });
}

// Periodic updates
setInterval(() => {
    fetchMetrics();
    fetchLogs();
    updateSpeedChart();
}, 2000);
