async function fetchMetrics() {
    const response = await fetch('/metrics');
    const data = await response.json();
    document.getElementById('total-vehicles').textContent = data.total_vehicle_count || 0;
    document.getElementById('front-distance').textContent = data.front_distance || 0;
    document.getElementById('back-distance').textContent = data.back_distance || 0;
}

async function fetchLogs() {
    const response = await fetch('/logs');
    const data = await response.json();
    const labels = data.map(log => log.Timestamp);
    const speeds = data.map(log => parseFloat(log.Speed));

    const ctx = document.getElementById('vehicleChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Vehicle Speed',
                data: speeds,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Timestamp'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Speed (km/h)'
                    }
                }
            }
        }
    });
}

// Fetch data periodically
setInterval(fetchMetrics, 1000);
fetchLogs();
