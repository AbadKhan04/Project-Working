// Fetch real-time metrics periodically
async function fetchMetrics() {
    try {
        const response = await fetch('/metrics');
        const data = await response.json();

        // Update DOM elements
        document.getElementById('total-vehicles').textContent = data.total_vehicle_count || 0;
        document.getElementById('front-distance').textContent = data.front_distance || 0;
        document.getElementById('back-distance').textContent = data.back_distance || 0;
    } catch (error) {
        console.error('Error fetching metrics:', error);
    }
}

// Fetch logs and update chart
function fetchLogs() {
    fetch('/logs')
      .then(response => response.json())
      .then(data => {
        const logsList = document.getElementById('logs-list');
        logsList.innerHTML = ''; // Clear any existing logs
  
        data.forEach(log => {
          const logItem = document.createElement('li');
          logItem.textContent = `Timestamp: ${log.Timestamp}, Vehicle_ID: ${log.Vehicle_ID}, Type: ${log.Type}, Speed: ${log.Speed}, Overtaking_Event: ${log.Overtaking_Event}`;
          logsList.appendChild(logItem);
        });
      })
      .catch(error => console.error('Error fetching logs:', error));
}

// Periodically fetch metrics and logs
setInterval(fetchMetrics, 1000);
setInterval(fetchLogs, 5000);
