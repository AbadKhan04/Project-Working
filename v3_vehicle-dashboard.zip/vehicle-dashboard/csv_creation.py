import csv

# File name for the sample
sample_file = 'vehicle_log.csv'

# Sample data
data = [
    ["Timestamp", "Vehicle_ID", "Type", "Speed", "Overtaking_Event"],
    ["2024-12-04 23:58:55", "car_0", "car", "0.00", "False"],
    ["2024-12-04 23:58:55", "car_1", "car", "0.00", "False"],
    ["2024-12-04 23:58:55", "car_2", "car", "10.50", "True"],
    ["2024-12-04 23:58:55", "car_3", "truck", "15.30", "False"]
]

# Write sample data to the CSV file
try:
    with open(sample_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)
    print(f"Sample CSV file '{sample_file}' created successfully.")
except Exception as e:
    print(f"Error creating sample file: {e}")
